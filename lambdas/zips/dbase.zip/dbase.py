import boto3
import json

dynamodb = boto3.resource('dynamodb')

def result(status, message):
    return{
        'statusCode': status,
        'body': message,
        'headers':{
            'Content-Type': 'application/json'
        }
    }

def lambda_handler(event, context):
    print('API event JSON:' + json.dumps(event))
    table = dynamodb.Table('weatherRecords')

    itemId = event['date']  # date string in ISO 8601 format
    minTemp = event['min']  # integer temp in F
    maxTemp = event['max']  # integer temp in F
    precip = event['precip']  # integer ppt in inches
            
    response = table.update_item(
        Key = {
            'isoDate': itemId
        },
        UpdateExpression="set min=:q",
        ExpressionAttributeValues={
            ':q': minTemp
        },
        UpdateExpression="set max=:q",
        ExpressionAttributeValues={
            ':q': minTemp
        },
        UpdateExpression="set ppt=:q",
        ExpressionAttributeValues={
            ':q': minTemp
        },
        ReturnValues="ALL_NEW"
    )

    print('Database response: '+ str(response))
    return response
